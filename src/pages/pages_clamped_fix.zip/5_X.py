import streamlit as st, pandas as pd
from pathlib import Path
import plotly.express as px
from datetime import timedelta

st.set_page_config(page_title="✖️ X (Twitter)", layout="wide")
BASE_DIR = Path(__file__).resolve().parents[2]; DATA_DIR = BASE_DIR/"data"/"sample"
TITLE="✖️ X (Twitter)"; PLATFORM="X"

st.header(TITLE); st.caption("Datos de muestra — luego conectamos API oficial.")
df = pd.read_csv(DATA_DIR/"sample_posts.csv", parse_dates=["date"])
df = df[df["platform"]==PLATFORM]
if df.empty:
    st.info("Sin datos de X en este período.")
    st.stop()

min_d, max_d = df["date"].min().date(), df["date"].max().date()
default_from = max(min_d, max_d - timedelta(days=30))
st.sidebar.subheader("Filtros X")
f = st.sidebar.date_input("Desde", default_from, min_value=min_d, max_value=max_d)
t = st.sidebar.date_input("Hasta",  max_d,       min_value=min_d, max_value=max_d)
mask=(df["date"].dt.date>=f)&(df["date"].dt.date<=t); df_now=df[mask]

c1,c2,c3=st.columns(3)
c1.metric("Publicaciones", int(df_now["posts"].sum()))
c2.metric("Vistas", int(df_now["views"].sum()))
c3.metric("Interacciones", int(df_now["interactions"].sum()))

st.markdown("### Evolución de vistas")
ts=df_now.groupby("date",as_index=False)["views"].sum()
st.plotly_chart(px.line(ts,x="date",y="views",title="Vistas por día",template="plotly_dark"),use_container_width=True)
st.subheader("Detalle"); st.dataframe(df_now.sort_values("date",ascending=False), use_container_width=True)
